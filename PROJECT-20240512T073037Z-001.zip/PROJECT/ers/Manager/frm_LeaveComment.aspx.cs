﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Manager_frm_LeaveComment : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            load_comment();
        }
    }
    private void load_comment()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("selectManagerComment", con);
        cmd.Parameters.AddWithValue("@expid", Session["expid"].ToString());
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            txt_comment.Text = dr["Comment"].ToString();
        }
        dr.Close();
        con.Close();
        if (txt_comment.Text != "")
        {
            btn_submit.Text = "Update Comment";
        }
        else
        {
            btn_submit.Text = "Submit Comment";
        }
    }
    protected void btn_submit_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("updateManagerComment", con);
        cmd.Parameters.AddWithValue("@expid", Session["expid"].ToString());
        cmd.Parameters.AddWithValue("@Comment_expr", txt_comment.Text);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        txt_comment.Text = "";
        if (btn_submit.Text == "Update Comment")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg", "alert('Comment Updated sucessfully');", true);
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg", "alert('Comment Submited sucessfully');", true);
        }
    }
    protected void btn_back_Click(object sender, EventArgs e)
    {
        Response.Redirect("ManagerHome.aspx");
    }
}