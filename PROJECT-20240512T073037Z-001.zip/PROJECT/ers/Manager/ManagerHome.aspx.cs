﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Manager_ManagerHome : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load_grid();
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            // Display the company name in italics.
            //e.Row.Cells[1].Text = "<i>" + e.Row.Cells[1].Text + "</i>";

            string text = ((Button)e.Row.FindControl("Button2")).Text;
            if (text == "Yes")
            {
                ((Button)e.Row.FindControl("Button2")).Text = "Reject";
            }
            else if (text == "No" || text == "")
            {
                ((Button)e.Row.FindControl("Button2")).Text = "Accept";
            }
        }

    }
    private void load_grid()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select_exp_detailsformanager", con);
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();
    }
    //protected void btn_search_Click(object sender, EventArgs e)
    //{
    //    con.Open();
    //    SqlCommand cmd = new SqlCommand("select_exp_detailsformanagerByDate", con);
    //    cmd.Parameters.AddWithValue("@startdate", txt_frmdate.Text);
    //    cmd.Parameters.AddWithValue("@enddate", txt_frmdate.Text);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    GridView1.DataSource = cmd.ExecuteReader();
    //    GridView1.DataBind();
    //    con.Close();
    //}
    //protected void btn_searchall_Click(object sender, EventArgs e)
    //{
    //    load_grid();
    //}
    //protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    if (e.CommandName == "leavecomment")
    //    {
           
         
    //    }
    //    else if (e.CommandName == "download")
    //    {
    //        string exp_id = GridView1.Rows[e.CommandArgument]
    //             string vfname = "";
       
    //    }
    //}
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string docpath = "";
        string sp = GridView1.Rows[e.RowIndex].Cells[0].Text.ToString();
        con.Open();
        SqlCommand cmd = new SqlCommand("Select doc_path from Emp_Exp_Entry Where Expid='" + sp + "'", con);
        SqlDataReader rd = cmd.ExecuteReader();
        if (rd.Read())
        {
            docpath = rd["doc_path"].ToString();
          
        }
        rd.Close();
        con.Close();
        Response.AppendHeader("Content-Disposition", "attachment; filename=" + docpath + "");
        Response.TransmitFile(Server.MapPath(docpath));
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Session["expid"] = GridView1.Rows[e.RowIndex].Cells[0].Text.ToString();
        Response.Redirect("frm_LeaveComment.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Button b = (Button)sender;
        GridViewRow row = (GridViewRow)b.NamingContainer;
        string expid = row.Cells[0].Text;
        string s = ((Button)sender).Text;
        string isaccept = "";
        if (s == "Accept")
        {
            isaccept = "Yes";
        }
        else if (s == "Reject")
        {
            isaccept = "No";
        }
        string managerid = Session["Manager"].ToString();
        AcceptOrReject(isaccept, managerid, expid);
    }
    private void AcceptOrReject(string isaccept, string managerid, string expid)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_Manager_approved", con);
        cmd.Parameters.AddWithValue("@isaccepted", isaccept);
        cmd.Parameters.AddWithValue("@expid", expid);
        cmd.Parameters.AddWithValue("@userid", managerid);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}