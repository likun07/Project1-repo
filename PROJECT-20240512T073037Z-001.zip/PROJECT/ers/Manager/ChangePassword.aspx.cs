﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Accountant_ChangePassword : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_change_Click(object sender, EventArgs e)
    {
        string existing_pwd = "";
        string man_id=Session["Manager"].ToString();
        con.Open();
        SqlCommand cmd = new SqlCommand("select Password from CreateUser where User_id='" + man_id + "'", con);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            existing_pwd = dr["Password"].ToString();
        }
        dr.Close();
        if (existing_pwd.Trim() == txt_oldpass.Text.Trim())
        {
            SqlCommand cmd1 = new SqlCommand("update CreateUser set password='" + txt_conpass.Text + "' where user_id='" + man_id + "'", con);
            cmd1.ExecuteNonQuery();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg", "alert('Password Changes sucessfully')", true);
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg", "alert('Your old Password does not match')", true);
        }
        con.Close();
    }
}