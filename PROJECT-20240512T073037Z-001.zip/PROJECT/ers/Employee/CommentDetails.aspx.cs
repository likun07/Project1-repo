﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class Employee_CommentDetails : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            load_comment();
        }
    }
    private void load_comment()
    {
        string ismanageraccept = "";
        string isdiracc = "";
        string isaccac = "";
        string expid = Session["expiid"].ToString();
        con.Open();
        SqlCommand cmd = new SqlCommand("select_exp_detailsIdWise", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@expid", expid);
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            ismanageraccept = dr["IsManagerApproved"].ToString().Trim();
            isdiracc = dr["IsDirectorApporved"].ToString().Trim();
            isaccac = dr["IsAccountantApproved"].ToString().Trim();
        }
        dr.Close();
        con.Close();
        if (ismanageraccept == "Yes" && isdiracc == "Yes" && isaccac == "Yes")
        {
            lbl_detailsofcurrentstatus.Text = "Your reimboursement amount is sucessfully approved";
            lbl_comments.Text = "";
        }
        else
        {
            if (ismanageraccept == "Yes" && isdiracc == "Yes" && isaccac == "No")
            {
                lbl_detailsofcurrentstatus.Text = "Your applied amount is pending in account section";
                lbl_comments.Text = "";
            }
            else if (ismanageraccept == "Yes" && isdiracc == "No")
            {
                lbl_detailsofcurrentstatus.Text = "Your applied amount is cancelled by director";
                con.Open();
                SqlCommand cmd1 = new SqlCommand("selectDirectorComment", con);
                cmd1.Parameters.AddWithValue("@expid", expid);
                cmd1.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.Read())
                {
                    lbl_comments.Text = dr1["Comment"].ToString();
                }
                dr1.Close();
                con.Close();
            }
            else if (ismanageraccept == "Yes" && isdiracc == "")
            {
                lbl_detailsofcurrentstatus.Text = "Your applied amount is pending in director chamber";
                lbl_comments.Text = "";
            }
            else if (ismanageraccept == "No")
            {
                lbl_detailsofcurrentstatus.Text = "Your applied amount is cancelled by manager";
                con.Open();
                SqlCommand cmd1 = new SqlCommand("selectManagerComment", con);
                cmd1.Parameters.AddWithValue("@expid", expid);
                cmd1.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr1 = cmd1.ExecuteReader();
                if (dr1.Read())
                {
                    lbl_comments.Text = dr1["Comment"].ToString();
                }
                dr1.Close();
                con.Close();
               
            }
            else if (ismanageraccept == "")
            {
                lbl_detailsofcurrentstatus.Text = "Your applied amount is pending in manager chamber";
                lbl_comments.Text = "";
            }
        }
    }
    protected void btn_back_Click(object sender, EventArgs e)
    {
        Response.Redirect("EmployeeHome.aspx");
    }
}