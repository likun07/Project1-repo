﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Employee_EmployeeHome : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load_grid();
        }
    }
    private void load_grid()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select_exp_detailsforemp", con);
        cmd.Parameters.AddWithValue("@empid", Session["Employee"].ToString());
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Session["expiid"] = GridView1.Rows[e.RowIndex].Cells[0].Text.ToString();
        Response.Redirect("CommentDetails.aspx");
    }
}