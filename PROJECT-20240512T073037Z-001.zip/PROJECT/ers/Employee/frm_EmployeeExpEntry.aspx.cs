﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class Employee_frm_EmployeeExpEntry : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            load_grid();
            btn_save.Visible = true;
            btn_update.Visible = false;
            load_exptype();
        }
    }
    private void load_exptype()
    {

        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("select Exp_TypeName,Exp_typeid from ExpenseTypeMaster", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        drp_exp_type.DataSource = dt;
        drp_exp_type.DataTextField = "Exp_TypeName";
        drp_exp_type.DataValueField = "Exp_typeid";
        drp_exp_type.DataBind();
        drp_exp_type.Items.Insert(0, "Select");
        con.Close();

       
    }
    private void load_grid()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select_exp_details", con);
        cmd.Parameters.AddWithValue("@empid", Session["Employee"].ToString());
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();
    }
    private void refresh()
    {
        drp_exp_type.SelectedIndex = 0;
        txt_date.Text = "";
        txt_amount.Text = "";
    }
    protected void btn_save_Click(object sender, EventArgs e)
    {
        string path = "";
        if (FileUpload1.HasFile)
        {
           
            string filename = FileUpload1.FileName;
             path = "~/UploadDocuments/" + filename;
             FileUpload1.SaveAs(Server.MapPath(path));
             con.Open();
             SqlCommand cmd = new SqlCommand("insert_exp_details", con);
             cmd.Parameters.AddWithValue("@exptypeid", drp_exp_type.SelectedValue);
             cmd.Parameters.AddWithValue("@empid", Session["Employee"].ToString());
             cmd.Parameters.AddWithValue("@amount", txt_amount.Text);
             cmd.Parameters.AddWithValue("@exp_applied_date", txt_date.Text);
            
             cmd.Parameters.AddWithValue("@docpath", path);
             cmd.CommandType = CommandType.StoredProcedure;
             cmd.ExecuteNonQuery();
             con.Close();
             load_grid();
             refresh();
        }
        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "msg", "alert('Please Select the File to be attached');", true);
        }
       
    }
    //private string findempname(string empcode)
    //{
    //    string firstname = "";
    //    string lastname = "";
    //    con.Open();
    //    SqlCommand cmd = new SqlCommand("findname", con);
    //    cmd.CommandType = CommandType.StoredProcedure;
    //    cmd.Parameters.AddWithValue("@empid", empcode);
    //    SqlDataReader dr = cmd.ExecuteReader();
    //    if (dr.Read())
    //    {
    //        firstname = dr["First_Name"].ToString();
    //        lastname = dr["Last_Name"].ToString();
    //    }

    //    dr.Close();
    //    con.Close();
    //    string fullname = firstname + " " + lastname;
    //    return fullname;
    //}
    protected void btn_refresh_Click(object sender, EventArgs e)
    {
        refresh();
        btn_save.Visible = true;
        btn_update.Visible = false;
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        btn_save.Visible = false;
        btn_update.Visible = true;
        HiddenField1.Value = GridView1.Rows[e.RowIndex].Cells[0].Text;
        drp_exp_type.SelectedItem.Text = GridView1.Rows[e.RowIndex].Cells[1].Text;
        txt_date.Text = GridView1.Rows[e.RowIndex].Cells[2].Text;
        txt_amount.Text = GridView1.Rows[e.RowIndex].Cells[3].Text;
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string empid = GridView1.Rows[e.RowIndex].Cells[0].Text;
        con.Open();
        SqlCommand cmd = new SqlCommand("delete_Expense_Type", con);
        cmd.Parameters.AddWithValue("@exp_id", empid);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
    }
    protected void btn_update_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("update_exp", con);
        cmd.Parameters.AddWithValue("@emp_id", HiddenField1.Value);
        cmd.Parameters.AddWithValue("@exp_type_id ", drp_exp_type.Text);
        cmd.Parameters.AddWithValue("@exp_type_id ", drp_exp_type.Text);
        cmd.Parameters.AddWithValue("@exp_applied_date", txt_date.Text);
        cmd.Parameters.AddWithValue("@amount", txt_amount.Text);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
        refresh();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
         
   
  

    }
}