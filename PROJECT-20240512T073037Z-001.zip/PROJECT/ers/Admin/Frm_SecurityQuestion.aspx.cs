﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class Frm_SecurityQuestion : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            load_grid();
        }
    }
    private void load_grid()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select_security_question", con);
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();
    }
    private void refresh()
    {
        txt_questionname.Text = "";
    }
    protected void btn_save_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert_security_question", con);
        cmd.Parameters.AddWithValue("@security_question", txt_questionname.Text);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
        refresh();
    }
    protected void btn_refresh_Click(object sender, EventArgs e)
    {
        refresh();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        HiddenField1.Value = GridView1.Rows[e.RowIndex].Cells[0].Text;
        txt_questionname.Text = GridView1.Rows[e.RowIndex].Cells[1].Text;
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string questionid = GridView1.Rows[e.RowIndex].Cells[0].Text;
        con.Open();
        SqlCommand cmd = new SqlCommand("delete_security_question", con);
        cmd.Parameters.AddWithValue("@security_questionid", questionid);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
    }
    protected void btn_update_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("update_security_question", con);
        cmd.Parameters.AddWithValue("@security_questionid", HiddenField1.Value);
        cmd.Parameters.AddWithValue("@security_question", txt_questionname.Text);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
        refresh();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {




    }
}