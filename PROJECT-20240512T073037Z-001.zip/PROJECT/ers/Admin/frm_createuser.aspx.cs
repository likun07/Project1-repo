﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class Admin_frm_createuser : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
      
        if (!Page.IsPostBack)
        {

            load_emptype();
            load_grid();
        }
    }
    private void load_emptype()
    {
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("select Emp_TypeId,Emp_Typename from EmployeeTypeMaster", con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        drp_usertype.DataSource = dt;
        drp_usertype.DataTextField = "Emp_Typename";
        drp_usertype.DataValueField = "Emp_TypeId";
        drp_usertype.DataBind();
        drp_usertype.Items.Insert(0, "Select");
        con.Close();
    }
    private void load_grid()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select_user", con);
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();
    }
    private void refresh()
    {
       
        
        drp_usertype.SelectedIndex = 0;
        txt_userid.Text = "";
        txt_password.Text = "";
        txt_username.Text = "";
    }
    protected void btn_save_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert_user", con);
        cmd.Parameters.AddWithValue("@usertypeId", drp_usertype.SelectedValue);
        cmd.Parameters.AddWithValue("@userid", txt_userid.Text);
        cmd.Parameters.AddWithValue("@username", txt_username.Text);
        cmd.Parameters.AddWithValue("@password", txt_password.Text);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
        refresh();
    }
    protected void btn_refresh_Click(object sender, EventArgs e)
    {
        refresh();
    }
  
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string empid = GridView1.Rows[e.RowIndex].Cells[1].Text;
        con.Open();
        SqlCommand cmd = new SqlCommand("delete_user", con);
        cmd.Parameters.AddWithValue("@uid", empid);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
    }
   
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {




    }
    protected void GridView1_RowUpdating1(object sender, GridViewUpdateEventArgs e)
    {

    }
    protected void GridView1_RowDeleting1(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void btn_update_Click1(object sender, EventArgs e)
    {

    }
  
}