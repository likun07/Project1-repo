﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class AdminHome : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            load_grid();
        }
    }
    private void load_grid()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select_registration", con);
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();
    }
    //protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    string Text = ((Button)GridView1.Rows[e.CommandArgument].FindControl("Button1")).Text;
    //    string isaccept = "";
    //    if (e.CommandName == "AccOrRej")
    //    {
    //         isaccept = "yes";
    //    }
    //    else if (e.CommandName == "REJ")
    //    {
    //         isaccept = "no";
    //    }
    //    acceptorreject(isaccept);
    //}
   
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
           
                // Display the company name in italics.
                //e.Row.Cells[1].Text = "<i>" + e.Row.Cells[1].Text + "</i>";

                string text = ((Button)e.Row.FindControl("Button1")).Text;
                if (text == "Yes")
                {
                    ((Button)e.Row.FindControl("Button1")).Text = "Reject";
                }
                else if (text == "No")
                {
                    ((Button)e.Row.FindControl("Button1")).Text = "Accept";
                }
        }
       
    }
    protected void cb_checkall_CheckedChanged(object sender, EventArgs e)
    {
        //foreach (GridViewRow gvr in GridView1.Rows)
        //{
        //    gvr.FindControl["cb_check"] = ((CheckBox)sender).Checked;
        //}
    }
    protected void cb_check_CheckedChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Button b=(Button)sender;
        GridViewRow row = (GridViewRow)b.NamingContainer;
        string userid = row.Cells[0].Text;
        string s = ((Button)sender).Text;
        string isaccept="";
        if (s == "Accept")
        {
            isaccept = "Yes";
        }
        else if (s == "Reject")
        {
            isaccept = "No";
        }
        string adminid = Session["Admin"].ToString();
        AcceptOrReject(isaccept,adminid, userid);
    }
    private void AcceptOrReject(string isaccept, string adminid, string userid)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("AcceptReject_Employee", con);
        cmd.Parameters.AddWithValue("@isaccept", isaccept);
        cmd.Parameters.AddWithValue("@empid", userid);
        cmd.Parameters.AddWithValue("@userid", adminid);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
    }

}