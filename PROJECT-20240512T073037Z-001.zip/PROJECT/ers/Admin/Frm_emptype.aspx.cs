﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class Frm_emptype : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            load_grid();
            btn_save.Visible = true;
            btn_update.Visible = false;
        }
    }
    private void load_grid()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select_EmployeeTypeMaster", con);
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();
    }
    private void refresh()
    {
        txt_emptype.Text = "";
    }
    protected void btn_save_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("insert_EmployeeTypeMaster", con);
        cmd.Parameters.AddWithValue("@emptypename", txt_emptype.Text);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
        refresh();
    }
    protected void btn_refresh_Click(object sender, EventArgs e)
    {
        refresh();
        btn_save.Visible = true;
        btn_update.Visible = false;
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        btn_save.Visible = false;
        btn_update.Visible = true;
        HiddenField1.Value = GridView1.Rows[e.RowIndex].Cells[0].Text;
        txt_emptype.Text = GridView1.Rows[e.RowIndex].Cells[1].Text;
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string empid = GridView1.Rows[e.RowIndex].Cells[0].Text;
        con.Open();
        SqlCommand cmd = new SqlCommand("delete_EmployeeTypeMaster", con);
        cmd.Parameters.AddWithValue("@emptypeid", empid);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
    }
    protected void btn_update_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("update_EmployeeTypeMaster", con);
        cmd.Parameters.AddWithValue("@emptypeid", HiddenField1.Value);
        cmd.Parameters.AddWithValue("@emptypename", txt_emptype.Text);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
        refresh();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
         
   
  

    }
}