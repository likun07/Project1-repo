﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Accountant_ReinboursementDetailsEmployeewise : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            load_reimboursementdetails();
        }
    }
    private void load_reimboursementdetails()
    {
        string fromdate = Session["frmdate"].ToString();
        string todate = Session["todate"].ToString();
        string empcode = Session["empcode"].ToString();
        lbl_empcode.Text = empcode;
        lbl_frmdate.Text = fromdate;
        lbl_todate.Text = todate;
         con.Open();
         SqlCommand cmd = new SqlCommand("Reimboursement_Details_empwise", con);
         cmd.Parameters.AddWithValue("@empid", empcode);
      
         cmd.Parameters.AddWithValue("@fromdate", fromdate);
         cmd.Parameters.AddWithValue("@todate", todate);
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();

        load_name(empcode);
    }
    private void load_name(string empcode)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_findEmpName", con);
        cmd.Parameters.AddWithValue("@empid", empcode);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            lblempname.Text = dr["name"].ToString();
        }
        dr.Close();
        con.Close();
    }

}