﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Accountant_AccountantHome : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            load_grid();
        }
    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {

            // Display the company name in italics.
            //e.Row.Cells[1].Text = "<i>" + e.Row.Cells[1].Text + "</i>";

            string text = ((Button)e.Row.FindControl("Button2")).Text.Trim();
            if (text == "Yes")
            {
                ((Button)e.Row.FindControl("Button2")).Text = "Reject";
            }
            else if (text == "No" || text == "")
            {
                ((Button)e.Row.FindControl("Button2")).Text = "Approve";
            }
        }

        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{

        //    // Display the company name in italics.
        //    //e.Row.Cells[1].Text = "<i>" + e.Row.Cells[1].Text + "</i>";

        //    string text = ((Button)e.Row.FindControl("Button2")).Text;
        //    if (text == "Yes")
        //    {
        //        ((Button)e.Row.FindControl("Button2")).Text = "Reject";
        //    }
        //    else if (text == "No" || text == "")
        //    {
        //        ((Button)e.Row.FindControl("Button2")).Text = "Accept";
        //    }
        //}

    }
    private void load_grid()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select_exp_detailsforAccountant", con);
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();
    }
    protected void btn_search_Click(object sender, EventArgs e)
    {

    }
 
   
    protected void btn_searchall_Click(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Button b = (Button)sender;
        GridViewRow row = (GridViewRow)b.NamingContainer;
        string expid = row.Cells[0].Text;
        string s = ((Button)sender).Text.Trim();
        string isaccept = "";
        if (s == "Approve")
        {
            isaccept = "Yes";
        }
        else if (s == "Reject")
        {
            isaccept = "No";
        }
        string Directorid = Session["Accountant"].ToString();
        AcceptOrReject(isaccept, Directorid, expid);
    }
    private void AcceptOrReject(string isaccept, string Directorid, string expid)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_Accountant_approved", con);
        cmd.Parameters.AddWithValue("@isaccepted", isaccept);
        cmd.Parameters.AddWithValue("@expid", expid);
        cmd.Parameters.AddWithValue("@userid", Directorid);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.ExecuteNonQuery();
        con.Close();
        load_grid();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}