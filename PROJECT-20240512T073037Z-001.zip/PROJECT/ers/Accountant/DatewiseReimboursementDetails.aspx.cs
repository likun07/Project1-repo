﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class Accountant_DatewiseReimboursementDetails : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_details_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("Reimboursement_Details_datewise", con);
        cmd.Parameters.AddWithValue("@fromdate", txt_frmdate.Text);
        cmd.Parameters.AddWithValue("@todate", txt_todate.Text);
        cmd.CommandType = CommandType.StoredProcedure;
        GridView1.DataSource = cmd.ExecuteReader();
        GridView1.DataBind();
        con.Close();
    }
    protected void btn_refresh_Click(object sender, EventArgs e)
    {
        clear();
    }
    private void clear()
    {
        Session["frmdate"] = txt_frmdate.Text;
        Session["todate"] = txt_todate.Text;
        txt_frmdate.Text = "";
        txt_todate.Text = "";
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Session["frmdate"] = txt_frmdate.Text;
        Session["todate"] = txt_todate.Text;
        Session["empcode"] = GridView1.Rows[e.RowIndex].Cells[0].Text;
        Response.Redirect("ReinboursementDetailsEmployeewise.aspx");
     
    }
}