﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
public class tran
{
    public SqlConnection cn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["con1"].ToString());
    public SqlCommand cm;
    public SqlDataAdapter adp;
    public DataSet ds = new DataSet();
    public string sql;
    public tran()
    {
        cn.Open();

    }
    public void addrec(string pro, string val)
    {
        sql = pro + " " + val;
        adp = new SqlDataAdapter(sql, cn);
        adp.Fill(ds, pro);
        
    }
   
}
